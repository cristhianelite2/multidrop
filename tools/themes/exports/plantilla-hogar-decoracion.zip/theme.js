/* ==========================================================================
   Multidrop — Plantilla "plantilla" — theme.js
   Consume window.Multidrop { store, products, product, cart, page,
   checkout, urls, csrf, modules } inyectado por la plataforma.
   Incluye fallback de datos demo SOLO para que el sandbox nunca truene
   si el runtime aún no inyectó nada (no afecta producción).
   ========================================================================== */
(function () {
  'use strict';

  function ready(fn) {
    if (document.readyState !== 'loading') fn();
    else document.addEventListener('DOMContentLoaded', fn);
  }

  function md() { return window.Multidrop || {}; }

  var DEMO_PRODUCTS = [
    { id: 'demo-1', name: 'Jarrón Terracota Alto', slug: 'jarron-terracota-alto', price: 690, price_formatted: '$690', image: '', badge: 'Hecho a mano', featured: true, description: 'Pieza torneada a mano en gres, esmalte mate.' },
    { id: 'demo-2', name: 'Cuenco Ceniza Nórdico', slug: 'cuenco-ceniza-nordico', price: 380, price_formatted: '$380', image: '', badge: '', featured: true, description: 'Cuenco de servir en tono ceniza, borde irregular.' },
    { id: 'demo-3', name: 'Candelero Latón Curvo', slug: 'candelero-laton-curvo', price: 450, price_formatted: '$450', image: '', badge: 'Nuevo', featured: false, description: 'Latón cepillado, curva orgánica, vela no incluida.' },
    { id: 'demo-4', name: 'Cesta Fibra Natural', slug: 'cesta-fibra-natural', price: 520, price_formatted: '$520', image: '', badge: '', featured: true, description: 'Tejida a mano en fibra de palma, ideal para plantas.' }
  ];

  function getProducts() {
    var m = md();
    if (Array.isArray(m.products) && m.products.length) return m.products;
    return DEMO_PRODUCTS;
  }

  function money(n) {
    if (typeof n !== 'number') return n || '';
    try { return new Intl.NumberFormat(document.documentElement.lang || 'es', { style: 'currency', currency: 'MXN' }).format(n); }
    catch (e) { return '$' + n; }
  }

  function field(p, keys) {
    for (var i = 0; i < keys.length; i++) {
      if (p[keys[i]] !== undefined && p[keys[i]] !== null && p[keys[i]] !== '') return p[keys[i]];
    }
    return '';
  }

  function productHandle(p) { return field(p, ['handle', 'slug']); }
  function productImage(p) {
    var img = field(p, ['image']);
    if (!img && Array.isArray(p.images) && p.images.length) img = p.images[0];
    return img || placeholderSVG();
  }
  function placeholderSVG() {
    return 'data:image/svg+xml;utf8,' + encodeURIComponent(
      '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400"><rect width="400" height="400" fill="#E0D3B8"/><path d="M140 260 Q140 160 200 150 Q260 160 260 260 Z" fill="#B54F2C" opacity="0.35"/><circle cx="200" cy="150" r="18" fill="#B54F2C" opacity="0.35"/></svg>'
    );
  }

  /* --------------------------- render product grids ------------------------ */
  function renderGrids() {
    var nodes = document.querySelectorAll('[data-md-products]');
    if (!nodes.length) return;
    var all = getProducts();

    nodes.forEach(function (el) {
      var list = all.slice();
      if (el.hasAttribute('data-md-manual')) {
        var ids = el.getAttribute('data-md-manual').split(',').map(function (s) { return s.trim(); }).filter(Boolean);
        list = ids.map(function (id) { return all.find(function (p) { return String(p.id) === id || productHandle(p) === id; }); }).filter(Boolean);
      } else if (el.getAttribute('data-md-featured') === 'true') {
        list = all.filter(function (p) { return field(p, ['featured', 'is_featured']); });
        if (!list.length) list = all;
      }
      var limit = parseInt(el.getAttribute('data-md-limit'), 10);
      if (limit) list = list.slice(0, limit);

      el.innerHTML = list.map(cardHTML).join('') || emptyGridHTML();
    });
  }

  function cardHTML(p) {
    var handle = productHandle(p);
    var url = field(p, ['url']) || ('product.html?h=' + encodeURIComponent(handle));
    var badge = field(p, ['badge']);
    return (
      '<article class="md-card" data-md-product-card data-id="' + escAttr(p.id) + '">' +
        '<a href="' + escAttr(url) + '" class="md-card__media">' +
          (badge ? '<span class="md-tag md-tag--rust md-tag--sm md-card__badge">' + escHTML(badge) + '</span>' : '') +
          '<img src="' + escAttr(productImage(p)) + '" alt="' + escAttr(field(p, ['name', 'title'])) + '" loading="lazy">' +
        '</a>' +
        '<div class="md-card__body">' +
          '<a href="' + escAttr(url) + '"><h3 class="md-card__title">' + escHTML(field(p, ['name', 'title'])) + '</h3></a>' +
          '<p class="md-card__desc">' + escHTML(field(p, ['summary', 'description']) || '') + '</p>' +
          '<div class="md-card__foot">' +
            '<span class="md-card__price">' + escHTML(field(p, ['price_formatted']) || money(p.price)) + '</span>' +
            '<button type="button" class="md-add" data-md-add-to-cart data-id="' + escAttr(p.id) + '" aria-label="Agregar al carrito">' +
              '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 6h15l-1.5 9h-12z"/><circle cx="9" cy="20" r="1"/><circle cx="18" cy="20" r="1"/><path d="M6 6L4 3H2"/></svg>' +
            '</button>' +
          '</div>' +
        '</div>' +
      '</article>'
    );
  }

  function emptyGridHTML() {
    return '<p class="md-note">Aún no hay productos para mostrar.</p>';
  }

  function escHTML(s) { return String(s == null ? '' : s).replace(/[&<>]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]; }); }
  function escAttr(s) { return escHTML(s).replace(/"/g, '&quot;'); }

  /* ------------------------------- PDP binding ------------------------------ */
  function bindProduct() {
    var scope = document.querySelector('[data-md-product]');
    if (!scope) return;
    var p = md().product;
    if (!p) {
      var handle = new URLSearchParams(location.search).get('h');
      p = getProducts().find(function (x) { return productHandle(x) === handle; }) || getProducts()[0];
    }
    if (!p) return;

    scope.querySelectorAll('[data-md-bind]').forEach(function (el) {
      var key = el.getAttribute('data-md-bind');
      var value;
      if (key === 'price_formatted') value = field(p, ['price_formatted']) || money(p.price);
      else if (key === 'image') value = productImage(p);
      else value = field(p, [key]);
      if (!value) return;
      if (el.tagName === 'IMG') el.src = value;
      else el.textContent = value;
    });

    var addBtn = scope.querySelector('[data-md-add-to-cart]');
    if (addBtn) addBtn.setAttribute('data-id', p.id);

    var thumbs = scope.querySelectorAll('[data-md-thumb]');
    var mainImg = scope.querySelector('[data-md-bind="image"]');
    thumbs.forEach(function (t) {
      t.addEventListener('click', function () {
        thumbs.forEach(function (x) { x.setAttribute('aria-current', 'false'); });
        t.setAttribute('aria-current', 'true');
        if (mainImg) mainImg.src = t.querySelector('img').src;
      });
    });
  }

  /* --------------------------------- cart ----------------------------------- */
  var LOCAL_KEY = 'md_demo_cart';

  function readLocalCart() {
    try { return JSON.parse(localStorage.getItem(LOCAL_KEY)) || []; } catch (e) { return []; }
  }
  function writeLocalCart(items) {
    try { localStorage.setItem(LOCAL_KEY, JSON.stringify(items)); } catch (e) { /* noop */ }
  }

  function getCartItems() {
    var m = md();
    if (m.cart && Array.isArray(m.cart.items)) return m.cart.items;
    return readLocalCart();
  }

  function cartCount(items) {
    return items.reduce(function (sum, it) { return sum + (parseInt(it.qty, 10) || 0); }, 0);
  }

  function updateCartCount() {
    var count = cartCount(getCartItems());
    document.querySelectorAll('[data-md-cart-count]').forEach(function (el) {
      el.textContent = String(count);
    });
  }

  function pulseCartBadge() {
    document.querySelectorAll('.md-cart-link').forEach(function (el) {
      el.classList.remove('md-pulse');
      void el.offsetWidth;
      el.classList.add('md-pulse');
    });
  }

  function addToCart(id, qty, evt) {
    qty = qty || 1;
    var m = md();
    if (m.Cart && typeof m.Cart.add === 'function') {
      m.Cart.add(id, qty);
    } else {
      var items = readLocalCart();
      var found = items.find(function (it) { return String(it.id) === String(id); });
      if (found) found.qty = (parseInt(found.qty, 10) || 0) + qty;
      else {
        var p = getProducts().find(function (x) { return String(x.id) === String(id); });
        items.push({
          id: id, qty: qty,
          name: p ? field(p, ['name', 'title']) : id,
          image: p ? productImage(p) : '',
          price: p ? p.price : 0,
          price_formatted: p ? (field(p, ['price_formatted']) || money(p.price)) : ''
        });
      }
      writeLocalCart(items);
    }
    updateCartCount();
    pulseCartBadge();
    if (evt) flyToCart(evt);
    renderCartPage();
  }

  function removeFromCart(id) {
    var m = md();
    if (m.Cart && typeof m.Cart.remove === 'function') {
      m.Cart.remove(id);
    } else {
      writeLocalCart(readLocalCart().filter(function (it) { return String(it.id) !== String(id); }));
    }
    updateCartCount();
    renderCartPage();
  }

  function setQty(id, qty) {
    qty = Math.max(0, parseInt(qty, 10) || 0);
    var m = md();
    if (m.Cart && typeof m.Cart.update === 'function') {
      m.Cart.update(id, qty);
    } else {
      var items = readLocalCart();
      if (qty === 0) items = items.filter(function (it) { return String(it.id) !== String(id); });
      else items.forEach(function (it) { if (String(it.id) === String(id)) it.qty = qty; });
      writeLocalCart(items);
    }
    updateCartCount();
    renderCartPage();
  }

  function flyToCart(evt) {
    var cartLink = document.querySelector('.md-cart-link');
    var origin = evt.currentTarget || evt.target;
    if (!cartLink || !origin || !origin.getBoundingClientRect) return;
    var start = origin.getBoundingClientRect();
    var end = cartLink.getBoundingClientRect();
    var ghost = document.createElement('span');
    ghost.className = 'md-flying';
    ghost.style.left = start.left + start.width / 2 - 17 + 'px';
    ghost.style.top = start.top + start.height / 2 - 17 + 'px';
    document.body.appendChild(ghost);
    requestAnimationFrame(function () {
      ghost.style.transform = 'translate(' + (end.left - start.left) + 'px,' + (end.top - start.top) + 'px) scale(.3)';
      ghost.style.opacity = '0';
    });
    setTimeout(function () { ghost.remove(); }, 600);
    origin.classList.add('md-bounce');
    setTimeout(function () { origin.classList.remove('md-bounce'); }, 420);
  }

  function bindAddToCartButtons() {
    document.addEventListener('click', function (evt) {
      var btn = evt.target.closest('[data-md-add-to-cart]');
      if (!btn) return;
      evt.preventDefault();
      var id = btn.getAttribute('data-id');
      var scope = btn.closest('[data-md-product]');
      var qtyInput = scope ? scope.querySelector('[data-md-qty]') : null;
      var qty = qtyInput ? parseInt(qtyInput.value, 10) || 1 : 1;
      addToCart(id, qty, evt);
    });
  }

  function bindQtyStepper() {
    document.addEventListener('click', function (evt) {
      var stepper = evt.target.closest('[data-md-qty-step]');
      if (!stepper) return;
      var wrap = stepper.closest('.md-qty');
      var input = wrap.querySelector('[data-md-qty]');
      var dir = stepper.getAttribute('data-md-qty-step') === 'up' ? 1 : -1;
      input.value = Math.max(1, (parseInt(input.value, 10) || 1) + dir);
    });
  }

  /* ------------------------------ cart page render --------------------------- */
  function renderCartPage() {
    var table = document.querySelector('[data-md-cart]');
    if (!table) return;
    var items = getCartItems();
    var empty = document.querySelector('[data-md-cart-empty]');
    var full = document.querySelector('[data-md-cart-full]');

    if (!items.length) {
      if (empty) empty.classList.remove('md-hidden');
      if (full) full.classList.add('md-hidden');
      return;
    }
    if (empty) empty.classList.add('md-hidden');
    if (full) full.classList.remove('md-hidden');

    table.innerHTML = items.map(function (it) {
      var price = it.price_formatted || money(it.price);
      return (
        '<div class="md-cart-row" data-id="' + escAttr(it.id) + '">' +
          '<img src="' + escAttr(it.image || placeholderSVG()) + '" alt="">' +
          '<div>' +
            '<div class="md-cart-row__name">' + escHTML(it.name) + '</div>' +
            '<div class="md-cart-row__price">' + escHTML(price) + '</div>' +
            '<button type="button" class="md-remove" data-md-remove data-id="' + escAttr(it.id) + '">Quitar</button>' +
          '</div>' +
          '<div class="md-qty">' +
            '<button type="button" data-md-cart-qty-step="down" data-id="' + escAttr(it.id) + '">−</button>' +
            '<input type="text" inputmode="numeric" value="' + escAttr(it.qty) + '" data-md-cart-qty data-id="' + escAttr(it.id) + '">' +
            '<button type="button" data-md-cart-qty-step="up" data-id="' + escAttr(it.id) + '">+</button>' +
          '</div>' +
          '<div class="md-cart-row__price">' + escHTML(money((it.price || 0) * (it.qty || 1))) + '</div>' +
        '</div>'
      );
    }).join('');

    renderSummary(items, document.querySelector('[data-md-summary]'));
    renderCheckoutSummary(items);
  }

  function renderSummary(items, el) {
    if (!el) return;
    var m = md();
    var subtotal = items.reduce(function (s, it) { return s + (it.price || 0) * (it.qty || 1); }, 0);
    var coupon = (m.checkout && m.checkout.discount) || 0;
    var magic = (m.checkout && m.checkout.magic_discount) || 0;
    var shipping = (m.checkout && m.checkout.shipping) || 0;
    var total = Math.max(0, subtotal - coupon - magic + shipping);

    el.innerHTML =
      line('Subtotal', money(subtotal)) +
      (coupon ? line('Cupón', '−' + money(coupon)) : '') +
      (magic ? line('Oferta especial', '−' + money(magic)) : '') +
      line('Envío', shipping ? money(shipping) : 'Se calcula en checkout') +
      line('Total', money(total), true);

    function line(label, value, isTotal) {
      return '<div class="md-summary__line' + (isTotal ? ' md-summary__line--total' : '') + '"><span>' + label + '</span><span>' + value + '</span></div>';
    }
  }

  function renderCheckoutSummary(items) {
    var el = document.querySelector('[data-md-checkout-items]');
    if (!el) return;
    el.innerHTML = items.map(function (it) {
      return (
        '<div class="md-checkout-summary__item">' +
          '<img src="' + escAttr(it.image || placeholderSVG()) + '" alt="">' +
          '<div style="flex:1">' +
            '<div class="md-cart-row__name" style="font-size:.92rem">' + escHTML(it.name) + '</div>' +
            '<div class="md-qtybadge">Cant. ' + escHTML(it.qty) + '</div>' +
          '</div>' +
          '<div class="md-card__price">' + escHTML(money((it.price || 0) * (it.qty || 1))) + '</div>' +
        '</div>'
      );
    }).join('');
    var totalsEl = document.querySelector('[data-md-checkout-summary]');
    renderSummary(items, totalsEl);
  }

  function bindCartRowEvents() {
    document.addEventListener('click', function (evt) {
      var rm = evt.target.closest('[data-md-remove]');
      if (rm) { removeFromCart(rm.getAttribute('data-id')); return; }
      var step = evt.target.closest('[data-md-cart-qty-step]');
      if (step) {
        var id = step.getAttribute('data-id');
        var input = document.querySelector('[data-md-cart-qty][data-id="' + CSS.escape(id) + '"]');
        var dir = step.getAttribute('data-md-cart-qty-step') === 'up' ? 1 : -1;
        var next = Math.max(0, (parseInt(input.value, 10) || 1) + dir);
        setQty(id, next);
      }
    });
    document.addEventListener('change', function (evt) {
      var input = evt.target.closest('[data-md-cart-qty]');
      if (input) setQty(input.getAttribute('data-id'), input.value);
    });
  }

  /* ------------------------------- modules toggling --------------------------- */
  function applyModuleFlags() {
    var flags = md().modules || {};
    document.querySelectorAll('[data-md-module]').forEach(function (el) {
      var name = el.getAttribute('data-md-module');
      if (flags.hasOwnProperty(name) && !flags[name]) el.style.display = 'none';
    });
  }

  /* ------------------------------ nav / misc ui -------------------------------- */
  function bindNav() {
    var burger = document.querySelector('[data-md-burger]');
    var links = document.querySelector('[data-md-nav-links]');
    if (burger && links) {
      burger.addEventListener('click', function () { links.classList.toggle('md-open'); });
    }
  }

  function bindCountrySearch() {
    document.querySelectorAll('[data-md-country]').forEach(function (input) {
      input.setAttribute('autocomplete', 'country-name');
    });
  }

  /* --------------------------------- init --------------------------------------- */
  ready(function () {
    renderGrids();
    bindProduct();
    updateCartCount();
    bindAddToCartButtons();
    bindQtyStepper();
    bindCartRowEvents();
    renderCartPage();
    applyModuleFlags();
    bindNav();
    bindCountrySearch();
  });

  window.MultidropTheme = { addToCart: addToCart, removeFromCart: removeFromCart, updateCartCount: updateCartCount };
})();
