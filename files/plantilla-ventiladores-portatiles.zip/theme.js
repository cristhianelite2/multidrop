/* ============================================================
   AIRO — Plantilla Multidrop · theme.js
   Solo UI: menú móvil, carruseles, steppers de qty, FAQ,
   animación en md:cart:add. NO agrega al carrito, NO usa
   localStorage para el carrito (Multidrop.Cart es el dueño).
   ============================================================ */
(function () {
  "use strict";

  document.addEventListener("DOMContentLoaded", init);
  function init() {
    initMobileMenu();
    initMediaCarousels();
    initVideoCarousels();
    initQtySteppers();
    initFaq();
    initCartAddAnimation();
    initLocaleCurrencyFallback();
  }

  /* ---------------- menú móvil ---------------- */
  function initMobileMenu() {
    var burger = document.querySelector("[data-md-burger]");
    var nav = document.querySelector(".md-nav");
    if (!burger || !nav) return;
    burger.addEventListener("click", function () {
      var open = nav.classList.toggle("is-open");
      burger.setAttribute("aria-expanded", open ? "true" : "false");
    });
    document.addEventListener("click", function (e) {
      if (!nav.contains(e.target) && !burger.contains(e.target)) {
        nav.classList.remove("is-open");
      }
    });
  }

  /* ---------------- carrusel de fotos (PDP) ---------------- */
  function initMediaCarousels() {
    document.querySelectorAll("[data-md-media-carousel]").forEach(function (root) {
      if (root.hasAttribute("data-md-gallery-locked")) return; // Multidrop ya montó esto
      var mainImg = root.querySelector("[data-md-gallery-main]");
      var thumbsWrap = root.querySelector("[data-md-gallery]");
      var countEl = root.querySelector("[data-md-media-count]");
      if (!mainImg || !thumbsWrap) return;

      var thumbs = Array.prototype.slice.call(thumbsWrap.querySelectorAll("img,button"));
      if (!thumbs.length) return;
      var idx = 0;

      function show(i) {
        idx = (i + thumbs.length) % thumbs.length;
        var src = thumbs[idx].getAttribute("data-src") || thumbs[idx].src;
        if (src) mainImg.src = src;
        thumbs.forEach(function (t, j) { t.classList.toggle("is-active", j === idx); });
        if (countEl) countEl.textContent = (idx + 1) + " / " + thumbs.length;
      }
      thumbs.forEach(function (t, i) {
        t.addEventListener("click", function () { show(i); });
      });
      root.querySelectorAll("[data-md-media-prev]").forEach(function (b) {
        b.addEventListener("click", function () { show(idx - 1); });
      });
      root.querySelectorAll("[data-md-media-next]").forEach(function (b) {
        b.addEventListener("click", function () { show(idx + 1); });
      });
      show(0);
    });
  }

  /* ---------------- carrusel de videos (PDP) ---------------- */
  function initVideoCarousels() {
    document.querySelectorAll("[data-md-video-carousel]").forEach(function (root) {
      var player = root.querySelector("[data-md-video-player]");
      var thumbsWrap = root.querySelector("[data-md-video-thumbs]");
      if (!player || !thumbsWrap) return;
      var thumbs = Array.prototype.slice.call(thumbsWrap.querySelectorAll("button"));
      if (!thumbs.length) {
        // sin videos: ocultar bloque
        root.setAttribute("hidden", "");
        return;
      }
      root.removeAttribute("hidden");
      function show(i) {
        var t = thumbs[i];
        var src = t.getAttribute("data-src");
        var poster = t.getAttribute("data-poster");
        if (src) player.src = src;
        if (poster) player.setAttribute("poster", poster);
        thumbs.forEach(function (th, j) { th.classList.toggle("is-active", j === i); });
      }
      thumbs.forEach(function (t, i) {
        t.addEventListener("click", function () { show(i); player.play && player.play(); });
      });
      show(0);
    });
  }

  /* ---------------- steppers de qty (solo UI, no escriben carrito) ---------------- */
  function initQtySteppers() {
    document.querySelectorAll("[data-md-qty-wrap]").forEach(function (wrap) {
      var input = wrap.querySelector("[data-md-qty]");
      var minus = wrap.querySelector("[data-md-qty-minus]");
      var plus = wrap.querySelector("[data-md-qty-plus]");
      if (!input) return;
      var step = parseInt(wrap.getAttribute("data-md-qty-step") || "1", 10);
      minus && minus.addEventListener("click", function () {
        var v = Math.max(1, (parseInt(input.value || "1", 10) - step));
        input.value = v;
        input.dispatchEvent(new Event("change", { bubbles: true }));
      });
      plus && plus.addEventListener("click", function () {
        var v = parseInt(input.value || "1", 10) + step;
        input.value = v;
        input.dispatchEvent(new Event("change", { bubbles: true }));
      });
    });
  }

  /* ---------------- acordeón FAQ ---------------- */
  function initFaq() {
    document.querySelectorAll(".md-faq__item").forEach(function (item) {
      var q = item.querySelector(".md-faq__q");
      var a = item.querySelector(".md-faq__a");
      if (!q || !a) return;
      q.addEventListener("click", function () {
        var isOpen = item.classList.contains("is-open");
        document.querySelectorAll(".md-faq__item.is-open").forEach(function (other) {
          if (other !== item) {
            other.classList.remove("is-open");
            other.querySelector(".md-faq__a").style.maxHeight = null;
          }
        });
        item.classList.toggle("is-open", !isOpen);
        a.style.maxHeight = !isOpen ? a.scrollHeight + "px" : null;
      });
    });
  }

  /* ---------------- animación al agregar al carrito ----------------
     Multidrop ya agrega el ítem y abre su propio modal (#md-atc-modal).
     Aquí SOLO animamos en respuesta al evento md:cart:add. */
  function initCartAddAnimation() {
    document.addEventListener("md:cart:add", function (e) {
      var cartLink = document.querySelector(".md-cart-link");
      if (cartLink) {
        cartLink.classList.remove("md-bump");
        // reflow para reiniciar animación
        void cartLink.offsetWidth;
        cartLink.classList.add("md-bump");
      }
      var btn = e.detail && e.detail.button;
      if (btn) {
        btn.classList.remove("md-added");
        void btn.offsetWidth;
        btn.classList.add("md-added");
      }
    });
  }

  /* ---------------- fallback visual si el runtime aún no rellenó selects ----------------
     Multidrop.locales / Multidrop.currencies rellenan las opciones reales;
     esto solo evita que el bloque se vea roto antes de esa hidratación. */
  function initLocaleCurrencyFallback() {
    document.querySelectorAll("[data-md-locale-currency]").forEach(function (block) {
      var localeSel = block.querySelector("[data-md-locale-select]");
      var currSel = block.querySelector("[data-md-currency-select]");
      if (localeSel && !localeSel.options.length && window.Multidrop && Multidrop.locales) {
        Multidrop.locales.forEach(function (loc) {
          var opt = document.createElement("option");
          opt.value = loc.code || loc;
          opt.textContent = (loc.label || loc.code || loc).toString().split("_")[0].toUpperCase();
          localeSel.appendChild(opt);
        });
      }
      if (currSel && !currSel.options.length && window.Multidrop && Multidrop.currencies) {
        Multidrop.currencies.forEach(function (cur) {
          var opt = document.createElement("option");
          opt.value = cur.code || cur;
          opt.textContent = cur.code || cur;
          currSel.appendChild(opt);
        });
      }
      localeSel && localeSel.addEventListener("change", function () {
        var url = new URL(window.location.href);
        url.searchParams.set("md_locale", localeSel.value);
        window.location.href = url.toString();
      });
      currSel && currSel.addEventListener("change", function () {
        var url = new URL(window.location.href);
        url.searchParams.set("md_currency", currSel.value);
        window.location.href = url.toString();
      });
    });
  }
})();
