(function () {
  "use strict";

  /* ------------------------------------------------------------------
   * 1) Fondo ambiental — malla de nodos animada (canvas)
   *    Puramente decorativo. Respeta prefers-reduced-motion.
   * ------------------------------------------------------------------ */
  function initBackgroundFX() {
    var canvas = document.querySelector(".md-bgfx__canvas");
    if (!canvas) return;
    var ctx = canvas.getContext("2d");
    var reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    var w, h, dpr, nodes = [];
    var NODE_COUNT_BASE = 60;

    function resize() {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = canvas.clientWidth = canvas.offsetWidth || window.innerWidth;
      h = canvas.clientHeight = canvas.offsetHeight || window.innerHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }

    function seed() {
      var count = Math.max(24, Math.min(NODE_COUNT_BASE, Math.round((w * h) / 26000)));
      nodes = [];
      for (var i = 0; i < count; i++) {
        nodes.push({
          x: Math.random() * w,
          y: Math.random() * h,
          vx: (Math.random() - 0.5) * 0.18,
          vy: (Math.random() - 0.5) * 0.18,
          r: Math.random() * 1.4 + 0.6
        });
      }
    }

    function step() {
      ctx.clearRect(0, 0, w, h);
      var linkDist = Math.max(90, Math.min(150, w / 8));

      for (var i = 0; i < nodes.length; i++) {
        var n = nodes[i];
        n.x += n.vx;
        n.y += n.vy;
        if (n.x < 0 || n.x > w) n.vx *= -1;
        if (n.y < 0 || n.y > h) n.vy *= -1;
      }

      for (var a = 0; a < nodes.length; a++) {
        for (var b = a + 1; b < nodes.length; b++) {
          var dx = nodes[a].x - nodes[b].x;
          var dy = nodes[a].y - nodes[b].y;
          var dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < linkDist) {
            var alpha = (1 - dist / linkDist) * 0.35;
            ctx.strokeStyle = "rgba(124,92,255," + alpha + ")";
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(nodes[a].x, nodes[a].y);
            ctx.lineTo(nodes[b].x, nodes[b].y);
            ctx.stroke();
          }
        }
      }

      for (var j = 0; j < nodes.length; j++) {
        var node = nodes[j];
        ctx.beginPath();
        ctx.arc(node.x, node.y, node.r, 0, Math.PI * 2);
        ctx.fillStyle = "rgba(41,246,200,0.75)";
        ctx.fill();
      }

      if (!reduceMotion) requestAnimationFrame(step);
    }

    resize();
    seed();

    if (reduceMotion) {
      // Dibuja un único frame estático y no anima más.
      step();
    } else {
      requestAnimationFrame(step);
    }

    var resizeTimer;
    window.addEventListener("resize", function () {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(function () {
        resize();
        seed();
        if (reduceMotion) step();
      }, 200);
    });
  }

  /* ------------------------------------------------------------------
   * 2) Menú móvil
   * ------------------------------------------------------------------ */
  function initMobileNav() {
    var toggle = document.querySelector("[data-md-nav-toggle]");
    var links = document.querySelector("[data-md-nav-links]");
    if (!toggle || !links) return;
    toggle.addEventListener("click", function () {
      var open = links.classList.toggle("is-open");
      toggle.setAttribute("aria-expanded", open ? "true" : "false");
    });
  }

  /* ------------------------------------------------------------------
   * 3) Stepper de cantidad en la PDP (solo UI; el add-to-cart real
   *    lo maneja Multidrop mediante [data-md-add-to-cart]).
   * ------------------------------------------------------------------ */
  function initQtyStepper() {
    document.querySelectorAll("[data-md-qty-wrap]").forEach(function (wrap) {
      var input = wrap.querySelector("[data-md-qty]");
      var minus = wrap.querySelector("[data-md-qty-minus]");
      var plus = wrap.querySelector("[data-md-qty-plus]");
      if (!input) return;
      minus && minus.addEventListener("click", function () {
        var v = Math.max(1, (parseInt(input.value, 10) || 1) - 1);
        input.value = v;
      });
      plus && plus.addEventListener("click", function () {
        var v = (parseInt(input.value, 10) || 1) + 1;
        input.value = v;
      });
    });
  }

  /* ------------------------------------------------------------------
   * 4) Selector de país con búsqueda (lista estática de países,
   *    sin depender de bandera por defecto).
   * ------------------------------------------------------------------ */
  var COUNTRIES = [
    "México", "Estados Unidos", "Canadá", "España", "Argentina", "Chile",
    "Colombia", "Perú", "Uruguay", "Paraguay", "Bolivia", "Ecuador",
    "Venezuela", "Costa Rica", "Panamá", "Guatemala", "Honduras",
    "El Salvador", "Nicaragua", "República Dominicana", "Puerto Rico",
    "Brasil", "Portugal", "Francia", "Alemania", "Italia", "Reino Unido",
    "Países Bajos", "Bélgica", "Suiza", "Irlanda", "Suecia", "Noruega",
    "Dinamarca", "Polonia", "Japón", "Corea del Sur", "China", "India",
    "Australia", "Nueva Zelanda", "Sudáfrica"
  ];

  function initCountrySelect() {
    var input = document.querySelector("[data-md-country-input]");
    var listId = "md-country-list";
    if (!input) return;
    var list = document.getElementById(listId);
    if (!list) {
      list = document.createElement("datalist");
      list.id = listId;
      document.body.appendChild(list);
    }
    COUNTRIES.forEach(function (name) {
      var opt = document.createElement("option");
      opt.value = name;
      list.appendChild(opt);
    });
    input.setAttribute("list", listId);
  }

  /* ------------------------------------------------------------------
   * 5) Animación "fly-to-cart" ligera al agregar un producto.
   *    Solo escucha el evento del runtime — NUNCA vuelve a agregar
   *    el ítem ni implementa su propio modal.
   * ------------------------------------------------------------------ */
  function initCartFx() {
    document.addEventListener("md:cart:add", function () {
      var badge = document.querySelector("[data-md-cart-count]");
      if (!badge) return;
      badge.animate(
        [
          { transform: "scale(1)" },
          { transform: "scale(1.35)" },
          { transform: "scale(1)" }
        ],
        { duration: 380, easing: "ease-out" }
      );
    });
  }

  document.addEventListener("DOMContentLoaded", function () {
    initBackgroundFX();
    initMobileNav();
    initQtyStepper();
    initCountrySelect();
    initCartFx();
  });
})();
