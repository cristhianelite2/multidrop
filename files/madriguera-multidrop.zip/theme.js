/* ==========================================================================
   Madriguera — theme.js
   Reglas: NUNCA agrega al carrito por listener propio, NUNCA localStorage de
   carrito, NUNCA re-renderiza grids de productos. Solo UI: menú, steppers,
   carruseles (si Multidrop no los monta) y animación en md:cart:add.
   ========================================================================== */
(function () {
  "use strict";

  // Declaración de idioma / moneda de la plantilla (Multidrop la lee para
  // poblar Multidrop.locales / Multidrop.currencies si aplica).
  window.MultidropTemplateConfig = {
    default_locale: "es_MX",
    locales: ["es_MX", "en_US"],
    default_currency: "MXN",
    currencies: ["MXN", "USD"]
  };

  document.addEventListener("DOMContentLoaded", init);

  function init() {
    initMobileNav();
    initQtyStampers();
    initPhotoCarousels();
    initVideoCarousels();
    initVariantUI();
    initCartAddPulse();
    initSocialProofDemo();
  }

  /* --------------------------- Menú móvil -------------------------------- */
  function initMobileNav() {
    var burger = document.querySelector("[data-md-burger]");
    var nav = document.querySelector("[data-md-mobile-nav]");
    if (!burger || !nav) return;
    burger.addEventListener("click", function () {
      var open = nav.classList.toggle("is-open");
      burger.setAttribute("aria-expanded", open ? "true" : "false");
    });
  }

  /* ------------------------- Steppers de qty (UI) ------------------------- */
  function initQtyStampers() {
    document.querySelectorAll("[data-md-qty-wrap]").forEach(function (wrap) {
      var input = wrap.querySelector("[data-md-qty]");
      var minus = wrap.querySelector("[data-md-qty-minus]");
      var plus = wrap.querySelector("[data-md-qty-plus]");
      if (!input) return;
      minus && minus.addEventListener("click", function () {
        var v = Math.max(1, (parseInt(input.value, 10) || 1) - 1);
        input.value = v;
        input.dispatchEvent(new Event("change", { bubbles: true }));
      });
      plus && plus.addEventListener("click", function () {
        var v = (parseInt(input.value, 10) || 1) + 1;
        input.value = v;
        input.dispatchEvent(new Event("change", { bubbles: true }));
      });
    });
  }

  /* ---------------- Carrusel de fotos (fallback si no hay lock) ----------- */
  function initPhotoCarousels() {
    document.querySelectorAll("[data-md-media-carousel]").forEach(function (root) {
      if (root.hasAttribute("data-md-gallery-locked")) return; // Multidrop ya lo montó
      var main = root.querySelector("[data-md-gallery-main]");
      var thumbsWrap = root.querySelector("[data-md-gallery]");
      var prev = root.querySelector(".md-media-carousel__nav--prev");
      var next = root.querySelector(".md-media-carousel__nav--next");
      if (!main || !thumbsWrap) return;
      var thumbs = Array.prototype.slice.call(thumbsWrap.querySelectorAll("img"));
      if (!thumbs.length) return;
      var idx = 0;
      function render() {
        main.src = thumbs[idx].src;
        thumbs.forEach(function (t, i) { t.classList.toggle("is-active", i === idx); });
        var counter = root.querySelector(".md-media-carousel__count");
        if (counter) counter.textContent = (idx + 1) + " / " + thumbs.length;
      }
      thumbs.forEach(function (t, i) {
        t.addEventListener("click", function () { idx = i; render(); });
      });
      prev && prev.addEventListener("click", function () { idx = (idx - 1 + thumbs.length) % thumbs.length; render(); });
      next && next.addEventListener("click", function () { idx = (idx + 1) % thumbs.length; render(); });
      render();
    });
  }

  /* ---------------- Carrusel de videos (fallback) -------------------------- */
  function initVideoCarousels() {
    document.querySelectorAll("[data-md-video-carousel]").forEach(function (root) {
      var thumbsWrap = root.querySelector("[data-md-video-thumbs]");
      var player = root.querySelector("[data-md-video-player]");
      if (!thumbsWrap || !player) return;
      var thumbs = Array.prototype.slice.call(thumbsWrap.querySelectorAll("[data-src]"));
      if (!thumbs.length) { root.hidden = true; return; }
      root.hidden = false;
      thumbs.forEach(function (t) {
        t.addEventListener("click", function () {
          player.src = t.getAttribute("data-src");
          var poster = t.getAttribute("data-poster");
          if (poster) player.setAttribute("poster", poster);
        });
      });
    });
  }

  /* -------------------------- Selección de variante (UI) ------------------- */
  function initVariantUI() {
    document.querySelectorAll("[data-md-variants]").forEach(function (root) {
      var options = root.querySelectorAll(".md-variant-option");
      options.forEach(function (opt) {
        opt.addEventListener("click", function () {
          options.forEach(function (o) { o.classList.remove("is-selected"); });
          opt.classList.add("is-selected");
          var img = opt.querySelector("img");
          var main = document.querySelector("[data-md-gallery-main]");
          if (img && main) main.src = img.src;
          var atc = document.querySelector("[data-md-add-to-cart]");
          if (atc && opt.dataset.variantId) atc.setAttribute("data-variant-id", opt.dataset.variantId);
        });
      });
    });
  }

  /* ------------- Animación al agregar al carrito (no re-agrega) ------------ */
  function initCartAddPulse() {
    document.addEventListener("md:cart:add", function (e) {
      var count = document.querySelectorAll("[data-md-cart-count]");
      count.forEach(function (el) {
        el.classList.remove("md-pulse");
        // force reflow to restart animation
        void el.offsetWidth;
        el.classList.add("md-pulse");
      });
      var link = document.querySelector(".md-cart-link");
      if (link) {
        link.animate(
          [{ transform: "scale(1)" }, { transform: "scale(1.16)" }, { transform: "scale(1)" }],
          { duration: 320, easing: "ease-out" }
        );
      }
    });
  }

  /* ------------------- Demo visual de prueba social (placeholder) --------- */
  function initSocialProofDemo() {
    var el = document.querySelector('[data-md-module="social_proof"]');
    if (!el) return;
    // Multidrop reemplaza el contenido/copy real; aquí solo garantizamos
    // que el hueco pueda animar su entrada si el runtime lo activa.
    var observer = new MutationObserver(function () {
      el.classList.add("is-visible");
    });
    observer.observe(el, { childList: true, subtree: true });
  }
})();
