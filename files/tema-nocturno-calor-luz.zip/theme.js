// theme.js — SOLO decoración / menú móvil. No toca carrito ni checkout.
document.addEventListener('DOMContentLoaded', function () {
  var toggle = document.querySelector('[data-md-nav-toggle]');
  var links = document.querySelector('.md-nav__links');

  if (toggle && links) {
    toggle.addEventListener('click', function () {
      links.classList.toggle('is-open');
      var expanded = links.classList.contains('is-open');
      toggle.setAttribute('aria-expanded', expanded ? 'true' : 'false');
    });
  }
});
