(function () {
  var css = [
    '#md-atc-modal.md-atc-modal,',
    '#md-atc-modal .md-atc-modal__card {',
    '  background: var(--md-panel, #1a212e) !important;',
    '  color: var(--md-ink, #f2f5f9) !important;',
    '  border: 1px solid var(--md-line, #2b3448) !important;',
    '}',
    '#md-atc-modal .md-atc-modal__title,',
    '#md-atc-modal .md-atc-modal__name,',
    '#md-atc-modal .md-atc-modal__price,',
    '#md-atc-modal h1, #md-atc-modal h2, #md-atc-modal h3 {',
    '  color: var(--md-accent-lamp, #ffd23f) !important;',
    '}',
    '#md-atc-modal .md-atc-modal__sub,',
    '#md-atc-modal .md-atc-modal__meta,',
    '#md-atc-modal .md-atc-modal__close {',
    '  color: var(--md-muted, #93a0b4) !important;',
    '}',
    '#md-atc-modal .md-atc-modal__product {',
    '  display: grid !important;',
    '  background: var(--md-panel-2, #212a3a) !important;',
    '  color: var(--md-ink, #f2f5f9) !important;',
    '  border: 1px solid var(--md-line, #2b3448) !important;',
    '  grid-template-columns: 64px minmax(0, 1fr) auto !important;',
    '  align-items: center !important;',
    '}',
    '#md-atc-modal .md-atc-modal__media { background: var(--md-panel, #1a212e) !important; }',
    '#md-atc-modal .md-atc-modal__copy,',
    '#md-atc-modal .md-atc-modal__copy * { color: var(--md-ink, #f2f5f9) !important; }',
    '#md-atc-modal .md-atc-modal__actions .md-btn--primary,',
    '#md-atc-modal .md-atc-modal__actions #md-atc-checkout {',
    '  background: linear-gradient(135deg, #ff6a39, #ff8c5a) !important;',
    '  color: #170d07 !important;',
    '  border: 0 !important;',
    '}',
    '#md-atc-modal .md-atc-modal__actions .md-btn--ghost,',
    '#md-atc-modal .md-atc-modal__actions a.md-btn--ghost,',
    '#md-atc-modal .md-atc-modal__actions button.md-btn--ghost,',
    '#md-atc-modal #md-atc-continue,',
    '#md-atc-modal #md-atc-cart {',
    '  background: var(--md-panel-2, #212a3a) !important;',
    '  color: var(--md-ink, #f2f5f9) !important;',
    '  border: 1px solid var(--md-line, #2b3448) !important;',
    '  box-shadow: none !important;',
    '}',
    '#md-atc-modal .md-atc-modal__actions .md-btn--ghost:hover,',
    '#md-atc-modal .md-atc-modal__actions a.md-btn--ghost:hover,',
    '#md-atc-modal .md-atc-modal__actions button.md-btn--ghost:hover,',
    '#md-atc-modal #md-atc-continue:hover,',
    '#md-atc-modal #md-atc-cart:hover {',
    '  background: color-mix(in srgb, #ff6a39 16%, #212a3a) !important;',
    '  color: #ffd23f !important;',
    '  border-color: #ff6a39 !important;',
    '}'
  ].join('\n');
  var el = document.getElementById('md-theme-nocturno-atc');
  if (!el) {
    el = document.createElement('style');
    el.id = 'md-theme-nocturno-atc';
    document.head.appendChild(el);
  }
  el.textContent = css;
})();

(function () {
  var css = [
    '/* tema-nocturno: conversión final */',
    '#md-social-proof:not(.md-hide){display:flex!important}',
    '#md-social-proof.md-sp-visible{opacity:1!important;visibility:visible!important;pointer-events:auto!important;transform:translateY(0)!important}',
    '#md-upsell-demo:not(.md-hide),[data-md-module="upsell"]:not(.md-hide){display:block!important;visibility:visible!important}',
    'aside.md-mod-cross-checkout,.md-mod-cross-checkout{display:block!important;width:100%!important}'
  ].join('\n');
  var el = document.createElement('style');
  el.id = 'md-theme-nocturno-conversion';
  el.textContent = css;
  document.head.appendChild(el);
})();

(function () {
  function showUrgency() {
    document.querySelectorAll('#md-module-urgency, [data-md-module="urgency"]').forEach(function (el) {
      el.classList.remove('md-hide');
      el.removeAttribute('hidden');
      el.setAttribute('aria-hidden', 'false');
      if (el.style && el.style.display === 'none') el.style.display = '';
    });
  }
  showUrgency();
  document.addEventListener('DOMContentLoaded', showUrgency);
})();