/* plantilla-hogar-decoracion — UI only (Multidrop owns cart / grids / ATC) */
(function () {
  'use strict';

  function ready(fn) {
    if (document.readyState !== 'loading') fn();
    else document.addEventListener('DOMContentLoaded', fn);
  }

  function bindNav() {
    var burger = document.querySelector('[data-md-burger], [data-md-nav-toggle]');
    var links = document.querySelector('[data-md-nav-links]');
    if (!burger || !links) return;
    burger.addEventListener('click', function () {
      var open = links.classList.toggle('md-open');
      burger.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }

  function bindQtyStepper() {
    document.addEventListener('click', function (evt) {
      var stepper = evt.target.closest('[data-md-qty-step]');
      if (!stepper) return;
      var wrap = stepper.closest('.md-qty, [data-md-qty-wrap]');
      if (!wrap) return;
      var input = wrap.querySelector('[data-md-qty]');
      if (!input) return;
      var dir = stepper.getAttribute('data-md-qty-step') === 'up' ? 1 : -1;
      input.value = String(Math.max(1, (parseInt(input.value, 10) || 1) + dir));
    });
  }

  function bindCartFx() {
    document.addEventListener('md:cart:add', function () {
      document.querySelectorAll('.md-cart-link, [data-md-cart-count]').forEach(function (el) {
        el.classList.remove('md-pulse', 'md-bounce');
        void el.offsetWidth;
        el.classList.add('md-pulse');
      });
    });
  }

  function bindChips() {
    document.querySelectorAll('.md-chip').forEach(function (chip) {
      chip.addEventListener('click', function () {
        document.querySelectorAll('.md-chip').forEach(function (c) {
          c.setAttribute('aria-pressed', 'false');
        });
        chip.setAttribute('aria-pressed', 'true');
      });
    });
  }

  ready(function () {
    bindNav();
    bindQtyStepper();
    bindCartFx();
    bindChips();
  });
})();