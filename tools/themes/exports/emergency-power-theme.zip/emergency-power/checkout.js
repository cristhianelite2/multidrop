/* checkout.js — checkout page only.
   Renders a read-only order summary from the same Cart data source theme.js
   already manages (MD.Cart) — no separate cart storage, no payment logic.
   The actual charge/submission flow is owned by the platform's gateway
   mount point (see [data-md-checkout-gateway] in checkout.html). */
(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    var MD = window.Multidrop;
    if (!MD || !MD.Cart || !MD.Theme) return;

    var linesEl = document.querySelector('[data-md-checkout-lines]');
    var subtotalEl = document.querySelector('[data-md-checkout-subtotal]');
    var totalEl = document.querySelector('[data-md-checkout-total]');
    if (!linesEl) return;

    var cart = MD.Cart.get();
    var items = cart.items || [];

    linesEl.innerHTML = items.map(function (item) {
      return '' +
        '<div class="md-checkout-summary__line">' +
          '<img src="' + (item.image || '') + '" alt="" loading="lazy">' +
          '<span class="md-checkout-summary__line-name">' + item.name + '</span>' +
          '<span class="md-checkout-summary__line-qty">×' + item.qty + '</span>' +
          '<span class="md-price">' + MD.Theme.formatPrice(item.qty * item.price) + '</span>' +
        '</div>';
    }).join('') || '<p class="text-muted" style="font-size:13px;">Your cart is empty — <a href="' + (MD.urls.catalog || '#') + '" style="color:var(--md-checkout-primary)">go pick something out</a>.</p>';

    var subtotal = MD.Cart.subtotal(cart);
    if (subtotalEl) subtotalEl.textContent = MD.Theme.formatPrice(subtotal);
    if (totalEl) totalEl.textContent = MD.Theme.formatPrice(subtotal); // shipping/tax added by the platform's checkout step
  });
})();
